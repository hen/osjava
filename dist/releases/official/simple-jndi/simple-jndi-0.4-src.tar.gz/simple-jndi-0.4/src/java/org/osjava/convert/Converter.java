package com.generationjava.convert;

public interface Converter {

    public Object convert(String value);

}
