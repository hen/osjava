java -classpath ../../../target/simple-jndi-0.8.jar:.:properties example_code.Example
