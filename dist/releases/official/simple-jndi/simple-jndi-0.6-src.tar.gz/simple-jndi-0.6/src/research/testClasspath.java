import java.net.URL;

public class testClasspath {
    static public void main(String[] args) throws Exception {
        Object obj = new testClasspath();
        URL url = obj.getClass().getClassLoader().getResource("thing.type");
        System.err.println(""+url);
        url = ClassLoader.getSystemClassLoader().getResource("thing.type.default.properties");
        System.err.println(""+url);
        url = ClassLoader.getSystemClassLoader().getResource("thing/type/default.properties");
        System.err.println(""+url);
    }
}
