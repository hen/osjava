java -classpath ../../../target/simple-jndi-0.8.jar:.:xml:/Users/hen/.maven/repository/genjava/jars/gj-xml-1.0.jar example_code.Example
