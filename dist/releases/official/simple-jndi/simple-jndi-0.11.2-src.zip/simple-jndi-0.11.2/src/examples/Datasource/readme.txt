Note that the properties option does not use a jndi.properties, while the 
ini and xml options do. This is merely to show the usage of -D parameters 
to set up the JNDI.
