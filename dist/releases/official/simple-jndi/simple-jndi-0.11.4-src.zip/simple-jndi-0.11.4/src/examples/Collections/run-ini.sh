java -classpath ../../../target/simple-jndi-0.8.jar:.:ini example_code.Example
