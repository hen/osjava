javac example_code/Example.java 
