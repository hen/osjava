package org.osjava.jndi;

import java.util.Hashtable;

class PropertiesStore extends Hashtable {

}
