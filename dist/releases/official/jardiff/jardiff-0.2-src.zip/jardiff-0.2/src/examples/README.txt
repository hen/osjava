This directory contains the following examples.
(They both require that you run maven uberjar first,
or change the library paths appropriately).

jardiff.sh - shell script to perform a jardiff between
             jardiff 0.1 and jardiff 0.2
build.xml - ant build script to perform a jardiff between
            jardiff 0.1 and jardiff 0.2
