package org.osjava.reportrunner;

public interface Nameable {

    String getName();

}
