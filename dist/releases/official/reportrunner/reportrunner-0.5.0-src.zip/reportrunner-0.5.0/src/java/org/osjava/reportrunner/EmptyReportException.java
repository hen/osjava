package org.osjava.reportrunner;

public class EmptyReportException extends ReportException {

    public EmptyReportException() {
        super();
    }

}
