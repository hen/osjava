package org.cyberiantiger.telnet;

public class UnknownTelnetOption extends AbstractTelnetOption {

    public UnknownTelnetOption(int option) {
	super(option);
    }

}
