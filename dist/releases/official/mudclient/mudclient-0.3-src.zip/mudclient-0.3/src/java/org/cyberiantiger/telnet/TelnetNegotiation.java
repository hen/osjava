package org.cyberiantiger.telnet;

public class TelnetNegotiation extends AbstractTelnetSubOption {

    public TelnetNegotiation(int option, int suboption) {
	super(option, suboption);
    }

}
