package org.cyberiantiger.telnet;

public interface BinaryData {

    public byte[] getBytes();

}
