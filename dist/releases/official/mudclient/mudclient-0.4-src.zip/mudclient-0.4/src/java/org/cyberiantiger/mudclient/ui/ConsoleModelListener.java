package org.cyberiantiger.mudclient.ui;

public interface ConsoleModelListener {

    public void consoleChanged();

}
