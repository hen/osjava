package org.cyberiantiger.console;

public class NullConsoleAction extends AbstractConsoleAction {

    public NullConsoleAction() {
    }

    public void apply(Console con) {
    }

}
