package org.cyberiantiger.console;

public interface ConsoleWriter {

    public void consoleAction(ConsoleAction con);

}
