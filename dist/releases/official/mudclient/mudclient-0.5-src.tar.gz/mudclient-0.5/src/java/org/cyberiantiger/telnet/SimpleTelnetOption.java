package org.cyberiantiger.telnet;

public class SimpleTelnetOption extends AbstractTelnetOption {

    public SimpleTelnetOption(int option) {
	super(option);
    }
}
