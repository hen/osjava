/*
 * Copyright (c) 2003, Henri Yandell
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or 
 * without modification, are permitted provided that the 
 * following conditions are met:
 * 
 * + Redistributions of source code must retain the above copyright notice, 
 *   this list of conditions and the following disclaimer.
 * 
 * + Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation 
 *   and/or other materials provided with the distribution.
 * 
 * + Neither the name of Genjava-Core nor the names of its contributors 
 *   may be used to endorse or promote products derived from this software 
 *   without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.generationjava.collections.typed;

import java.util.Map;
import java.util.HashMap;
import java.util.Collection;
import java.util.Set;

/**
 * A Map in which the key and values are of a known type.
 *
 * @author bayard@generationjava.com
 * @date 2001-05-07
 */
public class TypedMap extends AbstractTypedStructure implements Map {

    private Map myMap = null;
    private Class keyType = null;

    public TypedMap(Class type, Class keyType, Map m) {
        myMap = m;
        setType(type);
        this.keyType = keyType;
    }

    public TypedMap(Class type, Class keyType) {
        this(type, keyType, new HashMap());
    }

    public void checkKeyType(Object key) throws IllegalTypeException {
        checkType( keyType, key );
    }
    
    public void checkType(Map map) throws IllegalTypeException {
        if(map == null) { return ; }
        checkType(map.keySet());
        checkType(map.values());
    }

    /* map interface */

    // Removes all mappings from this map (optional operation) {. 
    public void clear() { 
        myMap.clear();
    }

    // Returns true if this map contains a mapping for the specified key. 
    public boolean containsKey(Object key) { 
        checkKeyType(key);
        return myMap.containsKey(key);
    }

    // Returns true if this map maps one or more keys to the specified value. 
    public boolean containsValue(Object value) { 
        checkType(value);
        return myMap.containsValue(value);
    }

    // Returns a set view of the mappings contained in this map. 
    public Set entrySet() { 
	    return myMap.entrySet();
    }

    // Compares the specified object with this map for equality. 
    public boolean equals(Object o) {
	// QUERY:  Is this right?
        return myMap.equals(o);
    }

    // Returns the value to which this map maps the specified key. 
    public Object get(Object key) { 
       checkKeyType(key);
       return myMap.get(key);
    }

    // Returns the hash code value for this map. 
    public int hashCode() { 
	// QUERY:  Is this right?
        return myMap.hashCode();
    }

    // Returns true if this map contains no key-value mappings. 
    public boolean isEmpty() {
        return myMap.isEmpty();
    }

    // Returns a set view of the keys contained in this map. 
    public Set keySet() { 
        return myMap.keySet();
    }

    // Associates the specified value with the specified key in this map (optional operation) {. 
    public Object put(Object key, Object value) { 
        checkKeyType(key);
        checkType(value);
        return myMap.put(key,value);
    }

    // Copies all of the mappings from the specified map to this map (optional operation) {. 
    public void putAll(Map t) { 
        checkType(t);
        myMap.putAll(t);
    }

    // Removes the mapping for this key from this map if present (optional operation) {. 
    public Object remove(Object key) { 
        checkKeyType(key);
        return myMap.remove(key);
    }

    // Returns the number of key-value mappings in this map. 
    public int size() { 
        return myMap.size();
    }

    // Returns a collection view of the values contained in this map. 
    public Collection values() { 
        return myMap.values();
    }

}
