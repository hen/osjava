/*
 * Copyright (c) 2003, Henri Yandell
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or 
 * without modification, are permitted provided that the 
 * following conditions are met:
 * 
 * + Redistributions of source code must retain the above copyright notice, 
 *   this list of conditions and the following disclaimer.
 * 
 * + Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation 
 *   and/or other materials provided with the distribution.
 * 
 * + Neither the name of Genjava-Core nor the names of its contributors 
 *   may be used to endorse or promote products derived from this software 
 *   without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.generationjava.security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.util.zip.Adler32;
import java.util.zip.CRC32;

import com.generationjava.lang.ByteArray;
import com.generationjava.lang.Constant;

/**
 * Utility class to make it easier to get hashed values.
 */
public class Securer {

    static public Constant CRC = new Constant("CRC");
    static public Constant UID = new Constant("UID");
    static public Constant ADLER = new Constant("ADLER");
    static public Constant HASH = new Constant("HASH");

    static public Securer getSecurer(Object algorithm) throws NoSuchAlgorithmException {
        if( (algorithm == CRC) || CRC.getValue().equals(algorithm)) {
            return new Securer() {
                CRC32 crc32 = new CRC32();
                public synchronized String getHash(String input) {
                    crc32.reset();
                    crc32.update(input.getBytes());
                    return ""+crc32.getValue();
                }
            };
        } else
        if( (algorithm == CRC) || ADLER.getValue().equals(algorithm)) {
            return new Securer() {
                Adler32 adler32 = new Adler32();
                public synchronized String getHash(String input) {
                    adler32.reset();
                    adler32.update(input.getBytes());
                    return ""+adler32.getValue();
                }
            };
        } else
        if( (algorithm == CRC) || HASH.getValue().equals(algorithm)) {
            return new Securer() {
                public synchronized String getHash(String input) {
                    return ""+input.hashCode();
                }
            };
        } else
        if( (algorithm == CRC) || UID.getValue().equals(algorithm)) {
            return new Securer() {
                public synchronized String getHash(String input) {
                    return "" + ( ( ((long)new Object().hashCode()) << 48) & System.currentTimeMillis() );
                }
            };
        }
        return new Securer(algorithm.toString());
    }

    private MessageDigest md;

    /**
     * Get a Securer for a particular algorithm.
     *
     * @throws NoSuchAlgorithmException if the algorithm does not exist.
     */
    public Securer(String algorithm) throws NoSuchAlgorithmException {
        try {
            md = MessageDigest.getInstance(algorithm);
        } catch(NoSuchAlgorithmException nsae) {
            nsae.printStackTrace();
        }
    }
    
    /**
     * Get a Securer for MD5.
     * Throws a RuntimeException if MD5 is unavailable.
     */
    public Securer() {
        try {
            md = MessageDigest.getInstance("MD5");
        } catch(NoSuchAlgorithmException nsae) {
            throw new RuntimeException("Unable to create Securer."+
                                                    "No MD5 Algorithm available.");
        }
    }

    /**
     * Get the hash for a string in hexadecimal string form.
     *
     * @param input String to hash
     *
     * @return String hexadecimal hashed value
     */
    public synchronized String getHash(String input) {
        byte[] bts = input.getBytes();
        md.update(bts);
        byte[] res = md.digest();
        md.reset();

        return ByteArray.byteArrayToString(res);
    }

    /**
     * See if a hashed value and a plain unhashed value are equal.
     *
     * @param hashed String hashed value.
     * @param plain String unhashed value.
     *
     * @return boolean was the hashed value the hash of the plain text.
     */
    public boolean hashEquals(String hashed, String plain) {
        if(hashed == null || plain == null) {
            return hashed == plain;
        } else {
            return hashed.equals( getHash(plain) );
        }
    }

}
