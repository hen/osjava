/*
 * Copyright (c) 2003, Henri Yandell
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or 
 * without modification, are permitted provided that the 
 * following conditions are met:
 * 
 * + Redistributions of source code must retain the above copyright notice, 
 *   this list of conditions and the following disclaimer.
 * 
 * + Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation 
 *   and/or other materials provided with the distribution.
 * 
 * + Neither the name of Genjava-Core nor the names of its contributors 
 *   may be used to endorse or promote products derived from this software 
 *   without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.generationjava.test;

/**
 * Useful when doing timings in a test.
 * @deprecated for Commons Lang.Stopwatch in 2.0
 */
public class StopWatch {

    // some test code
    static public void main(String[] strs) {
        StopWatch obj = new StopWatch();
        obj.start();
        try { Thread.currentThread().sleep(1500); } catch(InterruptedException ie) {;}
        obj.stop();
        System.out.println(obj);
    }

    private long startTime = -1;
    private long stopTime = -1;

    public StopWatch() {
    }
    
    /**
     * Start the stopwatch.
     */
    public void start() {
        this.startTime = System.currentTimeMillis();
    }
    
    /**
     * Stop the stopwatch.
     */
    public void stop() {
        this.stopTime = System.currentTimeMillis();
    }

    /**
     * Reset the stopwatch.
     */
    public void reset() {
        this.startTime = -1;
        this.stopTime = -1;
    }
        
    /**
     * Split the time.
     */
    public void split() {
        this.stopTime = System.currentTimeMillis();
    }

    /**
     * Remove a split.
     */
    public void unsplit() {
        this.stopTime = -1;
    }
    
    /**
     * Get the time on the stopwatch. This is either the 
     * time between start and latest split, between start and stop,
     * or the time between the start and the moment this method is called.
     */
    public long getTime() {
        if(stopTime == -1) {
            return (System.currentTimeMillis() - this.startTime);
        } else {
            return this.stopTime - this.startTime;
        }
    }
    
    public String toString() {
        return getTimeString();
    }
    
    /**
     * Get the time gap as a String.
     * In hours, minutes, seconds and milliseconds.
     */

     /*
    public String getTimeString() {
        long time = getTime();
        StringBuffer ret = new StringBuffer();
        ret.append(time/1000);
        ret.append(".");
        time = time - 1000*(time/1000);
        ret.append(time);
        return ret.toString();
    }
    */

    public String getTimeString() {
        int HIM = 60 * 60 * 1000;
        int MIM = 60 * 1000;
        int hours, minutes, seconds, milliseconds;
        long time = getTime();
        hours = (int) (time / HIM);
        time = time - (hours * HIM);
        minutes = (int) (time / MIM);
        time = time - (minutes * MIM);
        seconds = (int) (time / 1000);
        time = time - (seconds * 1000);
        milliseconds = (int) time;
 
        return hours + "h:" + minutes + "m:" + seconds + "s:" + milliseconds + "ms";
    }      

}
