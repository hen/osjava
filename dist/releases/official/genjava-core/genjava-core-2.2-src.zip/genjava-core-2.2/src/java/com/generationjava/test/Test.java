/*
 * Copyright (c) 2003, Henri Yandell
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or 
 * without modification, are permitted provided that the 
 * following conditions are met:
 * 
 * + Redistributions of source code must retain the above copyright notice, 
 *   this list of conditions and the following disclaimer.
 * 
 * + Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation 
 *   and/or other materials provided with the distribution.
 * 
 * + Neither the name of Genjava-Core nor the names of its contributors 
 *   may be used to endorse or promote products derived from this software 
 *   without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.generationjava.test;

import com.generationjava.collections.CollectionsW;
import com.generationjava.util.PropertiesLoader;
import java.util.Properties;

/**
 * A class which tests scaffolds.
 * It uses a properties file, com.generationjava.test.test.properties.
 * @deprecated for JUnit
 */
public class Test {

    static public void main(String[] strs) {
        if (strs.length == 0) {
            error(getUsage());
        }

        PropertiesLoader pl = new PropertiesLoader();
        Properties props = pl.findProperties("com/generationjava/test/test.properties");
        if(props != null) {
            String location = props.getProperty("scaffold.package");
            if (strs[0].indexOf(".") == -1) {
                strs[0] = location+"."+strs[0];
            }
            if (strs[0].indexOf("Scaffold") == -1) {
                strs[0] += "Scaffold";
            }
        } else {
            System.err.println("Can't find com.generationjava.test.test.properties.");
        }

        Class cl = null;
        try {
            cl = Class.forName(strs[0]);
        } catch (ClassNotFoundException cnfe) {
            error("Class not found: "+strs[0]);
        }

        Object obj = null;

        try {
            obj = cl.newInstance();
        } catch (IllegalAccessException iae) {
            error("Cant instantiate " + cl.getName() + " because " +
                    iae.getMessage());
        }
        catch (InstantiationException ie) {
            error("Cant instantiate " + cl.getName() + " because " +
                    ie.getMessage());
        }

        Scaffold scaf = null;

        try {
            scaf = (Scaffold) obj;
        } catch (ClassCastException cce) {
            error("Class not found: "+strs[0]);
        }
        scaf.init(CollectionsW.getSubArray(strs, 1));

        try {
            scaf.test();
        } catch(TestException te) {
            te.printStackTrace();
        }
    }

    static private void die(int i) {
        System.exit(i);
    }

    static public String getUsage() {
        return "java com.generationjava.test.Test <Scaffold class>";
    }

    static public void error(String str) {
        System.err.println(str);
        die(0);
    }
}
