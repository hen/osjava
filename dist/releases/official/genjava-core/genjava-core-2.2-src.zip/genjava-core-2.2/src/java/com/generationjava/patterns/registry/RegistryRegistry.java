/*
 * Copyright (c) 2003, Henri Yandell
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or 
 * without modification, are permitted provided that the 
 * following conditions are met:
 * 
 * + Redistributions of source code must retain the above copyright notice, 
 *   this list of conditions and the following disclaimer.
 * 
 * + Redistributions in binary form must reproduce the above copyright notice, 
 *   this list of conditions and the following disclaimer in the documentation 
 *   and/or other materials provided with the distribution.
 * 
 * + Neither the name of Genjava-Core nor the names of its contributors 
 *   may be used to endorse or promote products derived from this software 
 *   without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.generationjava.patterns.registry;

import java.util.Iterator;
import com.generationjava.patterns.Null;

/**
 * A Registry of Registries.
 */
public class RegistryRegistry implements Registry {

    private Registry registry;

    public RegistryRegistry() {
        this(new SimpleRegistry( new SingletonRegistryFactory(new SimpleRegistry() ) ) );
    }

    public RegistryRegistry(Registry registry) {
        registry.setNull( NullRegistry.NULL_REGISTRY );
        this.registry = registry;
    }

    public Registry getRegistry(Object type) {
        return (Registry)registry.get(type);
    }

    // Registry interface
    public void setRegistryFactory(RegistryFactory factory) {
        registry.setRegistryFactory(factory);
    }
    public RegistryFactory getRegistryFactory() {
        return registry.getRegistryFactory();
    }
    public void register(Object key, Object value) {
        registry.register(key,value);
    }
    public Object get(Object key) {
        return registry.get(key);
    }
    public void remove(Object key) {
        registry.remove(key);
    }
    public Iterator keys() {
        return registry.keys();
    }
    public void clear() {
        registry.clear();
    }
    public void setNull(Null value) {
        registry.setNull(value);
    }
    public Null getNull() {
        return registry.getNull();
    }

    // RegistryRegistry stuff.
    public void setRegistryFactory(Object type, RegistryFactory factory) {
        getRegistry(type).setRegistryFactory(factory);
    }
    public RegistryFactory getRegistryFactory(Object type) {
        return getRegistry(type).getRegistryFactory();
    }
    public void register(Object type, Object key, Object value) {
        getRegistry(type).register(key,value);
    }
    public Object get(Object type, Object key) {
        Object obj = getRegistry(type).get(key);
        if(obj == null) {
            return getRegistry(type).getNull();
        } else {
            return obj;
        }
    }
    public void clear(Object type) {
        getRegistry(type).clear();
    }
    public void remove(Object type, Object key) {
        getRegistry(type).remove(key);
    }
    public void setNull(Object type, Null value) {
        getRegistry(type).setNull(value);
    }
    public Null getNull(Object type) {
        return getRegistry(type).getNull();
    }
 
}
