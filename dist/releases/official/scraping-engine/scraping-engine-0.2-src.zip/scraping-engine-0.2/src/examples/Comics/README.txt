The accompanying system is an example of scraping engine at work, downloading various comics from the web.

IF DOWNLOADED FROM CVS:
To prepare things to run, assemble the jars in dependencies.list in a lib/ directory and run runc.sh to compile the files.

IF DOWNLOADED AS BINARY OR CVS:
To run the scrapers run test.sh, or to have it run at a certain time each night, run.sh.
