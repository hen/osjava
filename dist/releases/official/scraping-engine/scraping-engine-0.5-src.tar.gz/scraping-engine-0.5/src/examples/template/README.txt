The accompanying system is a basic template for using scraping engine.

Execute download.sh to grab the necessary dependencies, then execute run.sh to scrape the osjava.org front page.
