package com.generationjava.swing;

public interface GJTableSortListener {

    public void rowsMoved(GJTableEvent event);

}
