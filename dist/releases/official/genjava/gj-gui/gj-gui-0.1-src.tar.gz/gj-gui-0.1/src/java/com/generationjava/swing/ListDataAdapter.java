package com.generationjava.swing;

import javax.swing.event.*;

public class ListDataAdapter implements ListDataListener {
    public void contentsChanged(ListDataEvent ae) {
    }
    public void intervalAdded(ListDataEvent ae) {
    }
    public void intervalRemoved(ListDataEvent ae) {
    }
}
