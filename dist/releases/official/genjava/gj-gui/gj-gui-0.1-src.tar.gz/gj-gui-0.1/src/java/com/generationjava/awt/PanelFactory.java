package com.generationjava.awt;

import java.awt.Panel;

public interface PanelFactory {

    public Panel createPanel(String name);

}