package com.generationjava.swing;

public interface GJTableListener {

    public void rowRemoved(GJTableEvent event);

}
