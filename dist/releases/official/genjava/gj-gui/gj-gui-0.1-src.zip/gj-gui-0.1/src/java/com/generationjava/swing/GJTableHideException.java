package com.generationjava.swing;

public class GJTableHideException extends Exception {

    public GJTableHideException() {
        super();
    }

    public GJTableHideException(String msg) {
        super(msg);
    }

}
