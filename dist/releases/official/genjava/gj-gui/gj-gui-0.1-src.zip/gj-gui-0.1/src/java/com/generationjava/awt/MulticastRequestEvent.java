package com.generationjava.awt;

public class MulticastRequestEvent extends RequestEvent {

    public MulticastRequestEvent(String name, Object value) {
        super(name, value);
    }

}